[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=8915557&assignment_repo_type=AssignmentRepo)
Hint: [Markup Guide](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax)

# Project Name
*Project Name: Timely*

*Team Members: Mohammed Khaleelur Rehman, Hameeda Shaik, Michael Hartmann*

*Version 4.0*

## Summary of Project
*Every individual, especially the working professional and student, faces issues in organizing their daily activity schedule. This often results in stress from overlapping plans or conflicting meetings and the associated decision making.*

*Timely caters to the needs of all users who need an organized schedule, a routine of non conflicting activities to achieve targets towards their goals.*

*The aim of this app is to get the user into the habit of organizing, prioritizing and setting out a well planned daily routine that facilitates time management & sound health.*

## Project Analysis
### Target Audience
*(State your target demographic, be as specific as you can.  Why are you targeting this demographic?  How do you plan you reach it?)*

- Who: Students, Working Profesionals
- Why: Youth/Working people often have multiple goals to achieve in a limited time frame which results in them being stressed out.
- How: Advertising in universities and through influential working professionals

### Primary Purpose
*(Summarize the purpose of the project – could be something focused on the benefit of the target audience, your customers, your “company,” or even public good)*

1. Effective time management
2. Reduce stress
3. Set achievable tasks to target big goals

### Value Proposition
*(What are the pain points or problems you’re addressing?  For whom?  If possible, cite facts that support your claim that these are real pain points/problems to address)*

1. Decision Fatigue
    - Sources reveal on average an individual makes 35,000 choices/decisions per day. Timely helps reduce the probability of psychological condition 'decision fatigue' which deteriorates the quality of decisions.
    - Reference: https://go.roberts.edu/leadingedge/the-great-choices-of-strategic-leaders
2. Time Management
    - According to a study in 2021, 82% of people don't have an effective time management system.
    - Falling behind on life and daily routines are common symptoms to lack of effective time management system.
    - Reference: https://clockify.me/time-management-statistics#:~:text=The%20previously%20mentioned%20Gallup%27s%20report,%2C%20and%2025%25%20for%20sadness.

### Success Criteria
*(How will you know whether your app was successful?  Financial gain?  User satisfaction?  Market share?  Public good?  How will you measure the success?)*

*The following demonstrates success for Timely:*
- User satisfaction
- Number of users
- Financial gain

*The following measures success for Timely:*
- User satisfaction through reviews
- Number of users through number of downloads
- Financial gain through advertising

### Competitor Analysis
*(Summarize strengths/weaknesses of your competitors as compared to you – does not have to be in-depth, focus on things that relate directly to your purpose and value prop)*

*App Name: Microsoft's TODO App*
*Description: The app allows creating lists with names, colors and any number of list items as per user's choice.*

*Competitor Strengths:*
- Options for data object (attributes).
- Colorful

*Competitor Weakness:*
- Schedules number of activities in one time frame; does not restrict user from planning multiple activities simultaneously
- UX design feels busy; busy in over abundance of options/features with no clear "happy path"

### Monetization Model
*(Briefly propose a monetization model)*

*Advertising - By showing relevant advertisements*
*Premium Subscription - Provide weekly and monthly routine options*


### Initial Design
*The purpose of this section is to define the “Minimum Viable Product” (MVP).  It may also be useful to call out the scope and expected/known limitations for your product here.*

*Necessary components/interactions*
*P0 (Absolutely Needed)*
1. Create task form [name, duration, status]
2. Remove task
3. Mark a task completed & current score
4. List view of days for all created tasks
5. Implement database for the CRUD operation
6. Locked screen orientation
7. Show a reminder through notification

*P1 (Likely Needed)*
1. Create a Routine(Attend Classes/Food Routine/Coding time etc.)  
2. Be able to add tasks under a routine
3. List view of tasks under selected routine
4. List view of routines
5. Day/Week wise analysis of completed tasks

*P2 (Nice to Have)*
1. Login as a user (Google Authentication API)
2. User Profile/Account: Provide account info (name, count of routines, performance, etc.)*
3. Add type (weekly/monthly)
4. Error - when creating conflicting task (popup)
5. Search task/routine

*Crucial UI*
1. List of tasks
2. Creation of task page
3. List of days in week

*Minimum required navigational flow (Golden Path)*
*(See PDF File)*

*Services/APIs*
*P2 - Google Authentication API (if implemented)*

### UI/UX Design
*(Call out important UI/UX components to have an MVP – does not have to be polished, but should keep the audience, purpose, and value prop in mind)*

*(See PDF File)*


### Technical Architecture
*(What are the necessary components to support an MVP?  Data structures?  Storage considerations?  Web/cloud interactions?  Be sure to put in some thoughts as to how to measure your success here.  Call out dependencies on 3rd party services/APIs here, too)*

*Data Structure: ArrayList*
*Architectural Pattern: MVC*
*Object Design Patterns: Singleton*

*Storage Considerations:*
- Database: Room database
    - Type of Data:
        p0:
        - User-generated content (Creating Lists)
        p1:
        - Cached Data (Maybe)
        p2:
        - App State (Uninstall/Reinstall)
        - Resource Files (Images/Icons)

*Web/cloud interactions: save and retrieve from cloud not needed, data is stored on the device*

*Dependencies: if authentication is implemented (Google Authentication API)*

## Challenges and Open Questions
*Identify technical challenges that may come up (e.g. hardware limitations, access to data/services, performance issues, etc.) and propose some solutions to the identified challenges.  Also include questions on matters that you are unsure/unclear about that requires feedback from peers, users, or additional research.*

*Challenges Unique to Mobile Devices:*
1. Form Factor (orientation)
2. External Storage Dependencies (using the Room API)
3. Minimize Applicaton Resource Usage (through implementation of notifications feature)

*Questions answered from the previous Open Questions*
1. Storing user data - where to store? (cloud/device) and retrieving back on reinstalling (to address one problem unique to mobile)
2. Handling the app in various states (Minimuze in the middle of process and go to other all, receive a call when using app etc.)
3. Handling and managing the time zones