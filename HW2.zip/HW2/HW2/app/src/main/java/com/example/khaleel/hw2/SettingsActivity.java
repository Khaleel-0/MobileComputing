package com.example.khaleel.hw2;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity {

    TextView show_mode;
    Button remove_mode;
    Button Show_value;
    Button save_mode;
    EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_first2);

        Show_value=findViewById(R.id.show_value);
        save_mode=findViewById(R.id.save_value);
        show_mode=findViewById(R.id.show_value_text);
        input=findViewById(R.id.input);
        remove_mode=findViewById(R.id.remove_value);

        Show_value.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=getMode("key_1");

                if(data==null){
                    show_mode.setText("No Mode Set");
                }
                else{
                    show_mode.setText(data);
                }
            }
        });

        save_mode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(input.getText().toString().isEmpty()){
                    Toast.makeText(SettingsActivity.this, "Please Enter Mode", Toast.LENGTH_SHORT).show();
                    input.setError("Please input");
                    input.requestFocus();
                    return;
                }
                saveMode("key_1",input.getText().toString());
                input.setText("");
            }
        });

        remove_mode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeMode("key_1");
            }
        });
    }
    private String getMode(String key){
        SharedPreferences sharedPreferences=getSharedPreferences("Shared",0);
        if(sharedPreferences.contains(key)){
            String data=sharedPreferences.getString(key,null);
            return data;
        }
        else{
            return null;
        }
    }

    private void saveMode(String key,String value) {
        SharedPreferences sharedPreferences=getSharedPreferences("Shared",0);
        SharedPreferences.Editor editor=sharedPreferences.edit();

        editor.putString(key,value);
        editor.apply();
    }

    private void removeMode(String key) {
        SharedPreferences sharedPreferences=getSharedPreferences("Shared",0);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.remove(key);
        editor.apply();
    }


}