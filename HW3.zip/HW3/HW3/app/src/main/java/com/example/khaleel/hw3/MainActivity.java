package com.example.khaleel.hw3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private TextView timeText;
    private Button button;

    private CountDownTimer countDownTimer;
    private long timeLeftInMilliSeconds = 600000;
    private boolean timerRunning;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timeText = findViewById(R.id.countdown_text);
        button = findViewById(R.id.countdown_button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startStop();
            }
        });
        Log.i(TAG, "onCreate");
    }

    @Override
    protected void onPause() {
        super.onPause();
//      The timer gets automatically
//      paused when suspended onPause()
        stopTimer();
        Log.i(TAG, "onPause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this,"onResume method invoked ", Toast.LENGTH_SHORT).show();
        Log.i(TAG, "onResume");
    }

//  Methods to demonstrate timer logic
    public void startStop() {
        if(timerRunning) {
            stopTimer();
        }
        else {
            startTimer();
        }
    }

    public void startTimer() {
        countDownTimer = new CountDownTimer(timeLeftInMilliSeconds,1000) {
            @Override
            public void onTick(long l) {
                timeLeftInMilliSeconds = l;
                updateTimer();
            }

            @Override
            public void onFinish() {}
        }.start();

        button.setText("STOP");
        timerRunning = true;
    }

    public void stopTimer() {
        countDownTimer.cancel();
        button.setText("RESUME");
        timerRunning = false;
    }

    public void updateTimer() {
        int minutes = (int) timeLeftInMilliSeconds/60000;
        int seconds = (int) timeLeftInMilliSeconds % 60000 / 1000;

        String timeLeftText;
        timeLeftText = "" + minutes;
        timeLeftText += ":";
        if(seconds < 10) timeLeftText += "0";
        timeLeftText += seconds;

        timeText.setText(timeLeftText);
    }


//  Methods demonstrating other activity life cycle
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG, "onStart");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "onStop");
    }
}